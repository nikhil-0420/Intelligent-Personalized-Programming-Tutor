import { BrowserRouter, Routes, Route } from "react-router-dom";
import NavBar from "./components/NavBar";
import HomePage from "./pages/HomePage";
import ChatPage from "./pages/ChatPage";
import EvaluationPage from "./pages/EvaluationPage";

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-base px-6 py-8">
        <div className="mx-auto max-w-[1100px]">
          <NavBar />
          <div className="mt-6">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/chat" element={<ChatPage />} />
              <Route path="/evaluation" element={<EvaluationPage />} />
            </Routes>
          </div>
        </div>
      </div>
    </BrowserRouter>
  );
}
