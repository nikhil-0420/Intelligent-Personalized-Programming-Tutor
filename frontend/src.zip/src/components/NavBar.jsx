import { NavLink } from "react-router-dom";

export default function NavBar() {
  const linkClass = ({ isActive }) =>
    `text-[13px] transition-colors ${isActive ? "text-pine font-medium" : "text-muted hover:text-text"}`;

  return (
    <header className="flex items-center justify-between border-b border-text/10 px-6 py-4">
      <div className="flex items-center gap-2">
        <div className="h-2 w-2 rounded-full bg-pine" />
        <span className="text-sm font-medium text-text">Programming tutor</span>
      </div>
      <nav className="flex gap-5">
        <NavLink to="/" end className={linkClass}>
          Home
        </NavLink>
        <NavLink to="/chat" className={linkClass}>
          Chat
        </NavLink>
        <NavLink to="/evaluation" className={linkClass}>
          Evaluation
        </NavLink>
      </nav>
    </header>
  );
}
