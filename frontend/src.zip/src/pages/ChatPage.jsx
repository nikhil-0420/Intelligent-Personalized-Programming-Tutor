import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { sendMessage, getSkillStates, getTopics, getRecommendation } from "../api";
import ChatPanel from "../components/ChatPanel";
import TopicPicker from "../components/TopicPicker";
import TopicChip from "../components/TopicChip";
import InsightDrawer from "../components/InsightDrawer";

const STUDENT_ID = 1;

export default function ChatPage() {
  const location = useLocation();
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [lastTrace, setLastTrace] = useState(null);
  const [skills, setSkills] = useState([]);
  const [topics, setTopics] = useState([]);
  const [recommendation, setRecommendation] = useState(null);
  const [selectedTopic, setSelectedTopic] = useState("");
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    getTopics().then(setTopics).catch(console.error);
    getRecommendation(STUDENT_ID).then(setRecommendation).catch(console.error);
    refreshSkills();
    if (location.state?.initialTopic) {
      setSelectedTopic(location.state.initialTopic);
    }
  }, [location.state]);

  const refreshSkills = () => {
    getSkillStates(STUDENT_ID).then(setSkills).catch(console.error);
  };

  const handleSend = async (text) => {
    setMessages((prev) => [...prev, { role: "student", text }]);
    setLoading(true);
    try {
      const res = await sendMessage(STUDENT_ID, selectedTopic || null, text);
      const plannerFrame = res.agent_trace.find((f) => f.agent === "planner");
      setMessages((prev) => [
        ...prev,
        {
          role: "tutor",
          text: res.tutor_response,
          trace: res.agent_trace,
          plannerNote: plannerFrame ? `planner routed to ${plannerFrame.recommended_topic}` : null,
        },
      ]);
      setLastTrace(res.agent_trace);
      refreshSkills();
    } catch (err) {
      setMessages((prev) => [...prev, { role: "tutor", text: `Error: ${err.message}` }]);
    } finally {
      setLoading(false);
    }
  };

  const currentPKnow = skills.find((s) => s.topic_slug === selectedTopic)?.p_know;

  if (!selectedTopic) {
    return (
      <TopicPicker
        topics={topics}
        skills={skills}
        recommendation={recommendation}
        onSelect={setSelectedTopic}
      />
    );
  }

  return (
    <>
      <div className="mb-4 flex items-center justify-between">
        <TopicChip topicSlug={selectedTopic} pKnow={currentPKnow} onChange={() => setSelectedTopic("")} />
        <button
          onClick={() => setDrawerOpen(true)}
          className="flex items-center gap-1.5 rounded-lg border border-text/15 px-3 py-1.5 text-xs text-muted hover:text-text"
        >
          insight panel <span className="text-clay">›</span>
        </button>
      </div>

      <div style={{ height: "64vh" }}>
        <ChatPanel messages={messages} onSend={handleSend} loading={loading} />
      </div>

      <InsightDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        skills={skills}
        lastTrace={lastTrace}
      />
    </>
  );
}
